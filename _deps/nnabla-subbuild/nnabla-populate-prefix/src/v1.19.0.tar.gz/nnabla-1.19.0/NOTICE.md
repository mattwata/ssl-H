NNabla: Neural Network Libraries
Copyright 2018 Sony Corporation

This product includes software developed at Sony corporation and the 
contributors (https://github.com/sony/nnabla).

Relies on third-party open source software.
See [LICENSES](third_party/LICENSES.md) for more information.

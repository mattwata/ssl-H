Data exchange file format
=========================

.. automodule:: nnabla.utils.nnp_format

.. autofunction:: nnabla.utils.nnp_format.nnp_version

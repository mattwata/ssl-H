.. _nd_array:

NdArray
=======

.. autoclass:: nnabla.NdArray
    :members:

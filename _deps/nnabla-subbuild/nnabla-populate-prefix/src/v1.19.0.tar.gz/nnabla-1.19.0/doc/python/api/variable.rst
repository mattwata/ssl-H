.. _variable:

Variable
========

.. automodule:: nnabla.variable

.. autoclass:: nnabla.Variable
    :members:
    :inherited-members:
    :show-inheritance:

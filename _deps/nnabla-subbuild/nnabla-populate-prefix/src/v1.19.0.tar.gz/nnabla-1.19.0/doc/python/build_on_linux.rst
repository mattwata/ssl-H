.. _python-build-on-linux:

Build on Linux
--------------

Documentation has been moved to `Github repository <https://github.com/sony/nnabla/tree/master/doc/build/build.md>`_.

Modules
=======

The :class:`nnabla.core.module.Module` class represents a construction block of neural network.


.. automodule:: nnabla.core.module


Module
------

.. autoclass:: Module
    :members:


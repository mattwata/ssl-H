Build on Linux with Distributed Training 
----------------------------------------

Documentation has been moved to `Github repository <https://github.com/sony/nnabla-ext-cuda/blob/master/doc/build/build_distributed.md>`_.

Misc
====

Python function profiler utilities
----------------------------------

.. automodule:: nnabla.utils.function_profile

.. autofunction:: profile

.. autoclass:: FunctionProfile
    :members:

.. _rnn-utils:

RNN Utils
=========


.. autoclass:: nnabla.utils.rnn.PackedSequence
    :members:

.. autofunction:: nnabla.utils.rnn.pad_sequence

.. autofunction:: nnabla.utils.rnn.pack_padded_sequence

.. autofunction:: nnabla.utils.rnn.pack_sequence

.. autofunction:: nnabla.utils.rnn.pad_packed_sequence

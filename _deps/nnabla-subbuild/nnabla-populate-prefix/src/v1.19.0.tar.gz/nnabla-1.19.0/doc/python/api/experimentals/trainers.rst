Trainers
========


.. autoclass:: nnabla.experimental.trainers.Trainer
    :members:

.. autoclass:: nnabla.experimental.trainers.NaiveClassificationTrainer
    :members:

.. autoclass:: nnabla.experimental.trainers.NaiveRegressionTrainer
    :members:

.. autoclass:: nnabla.experimental.trainers.Updater
    :members:

.. autoclass:: nnabla.experimental.trainers.Evaluator


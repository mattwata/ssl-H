Contrib
=======

.. automodule:: nnabla.contrib


.. _extension-context:

Extension Context
-----------------

.. automodule:: nnabla.contrib.context

.. autofunction:: nnabla.contrib.context.extension_context

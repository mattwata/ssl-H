Grad
====

.. automodule:: nnabla.grad

.. autofunction:: nnabla.grad.grad

.. autofunction:: nnabla.backward_functions.register

.. autofunction:: nnabla.backward_functions.show_registry

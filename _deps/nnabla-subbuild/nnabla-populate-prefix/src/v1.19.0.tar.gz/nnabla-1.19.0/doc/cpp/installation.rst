.. _cpp-lib-installation:

Build C++ libraries
===================

Documentation has been moved to `Github repository <https://github.com/sony/nnabla/tree/master/doc/build/build_cpp_utils.md>`_.

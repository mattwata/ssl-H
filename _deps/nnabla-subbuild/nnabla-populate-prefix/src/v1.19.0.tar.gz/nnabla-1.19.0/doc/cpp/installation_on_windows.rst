.. _cpp-lib-installation-windows:

Build C++ libraries on Windows
==============================

Documentation has been moved to `Github repository <https://github.com/sony/nnabla/tree/master/doc/build/build_cpp_utils_windows.md>`_.

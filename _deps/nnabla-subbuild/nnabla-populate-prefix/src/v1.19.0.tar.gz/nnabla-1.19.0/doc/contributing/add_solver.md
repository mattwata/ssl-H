# Adding a new solver

## Overview

TODO: Write me.

## Prerequisites

TODO: Write me.

## Write a definition in YAML

TODO: Write me.

## Generate code template by CMake

TODO: Write me.

## Write your solver implementation

TODO: Write me.

## Write unit testing

TODO: Write me.

## (DO NOT FORGET!) Add a solver doc to sphinx.

TODO: Write me.

## You want to add a CUDA solver too?

We know many developers use CUDA to accelerate processing speed. See [a contribution guide of NNabla's CUDA extension](https://github.com/sony/nnabla-ext-cuda/blob/master/CONTRIBUTING.md).
